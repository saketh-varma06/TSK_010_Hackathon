const mongoose = require('mongoose');
const OrderSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  buyerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  farmerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  quantityOrdered: Number,
  totalPrice: Number,
  status: { type: String, enum: ['Pending','Accepted','Completed','Cancelled'], default: 'Pending' },
  orderDate: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Order', OrderSchema);
