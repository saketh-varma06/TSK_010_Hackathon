const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const auth = require('../middleware/auth');

// Place order (buyer)
router.post('/', auth, async (req, res) => {
  try{
    const { productId, quantityOrdered } = req.body;
    const buyerId = req.user.id;
    const product = await Product.findById(productId);
    if(!product) return res.status(404).json({msg:'Product not found'});
    const totalPrice = (product.pricePerKg || 0) * (quantityOrdered || 0);
    const order = new Order({ productId, buyerId, farmerId: product.farmerId, quantityOrdered, totalPrice });
    await order.save();
    res.json(order);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Get orders for buyer
router.get('/buyer/:buyerId', auth, async (req, res) => {
  try{
    const orders = await Order.find({ buyerId: req.params.buyerId }).populate('productId').populate('farmerId','name contact');
    res.json(orders);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Get orders for farmer
router.get('/farmer/:farmerId', auth, async (req, res) => {
  try{
    const orders = await Order.find({ farmerId: req.params.farmerId }).populate('productId').populate('buyerId','name contact');
    res.json(orders);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

// Update order status (farmer)
router.put('/:id/status', auth, async (req, res) => {
  try{
    const order = await Order.findById(req.params.id);
    if(!order) return res.status(404).json({msg:'Not found'});
    // Only farmer who owns the product can update
    if(order.farmerId.toString() !== req.user.id) return res.status(403).json({msg:'Not allowed'});
    order.status = req.body.status || order.status;
    await order.save();
    res.json(order);
  }catch(err){ console.error(err); res.status(500).send('Server error'); }
});

module.exports = router;
