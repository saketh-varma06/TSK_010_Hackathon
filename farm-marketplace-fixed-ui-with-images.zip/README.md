# Farm Marketplace (Hackathon Starter)

## Overview
Minimal full-stack web application for farmers to list produce and buyers to place orders.
Includes:
- Node.js + Express backend with MongoDB (Mongoose)
- Simple JWT auth for users (farmer/buyer/admin)
- Product listing, order placement, order status update
- Static frontend under `/public` that demonstrates flows

## Setup (locally)
1. Install Node.js (v16+) and npm.
2. Create a MongoDB database and get the connection URI (example `mongodb://localhost:27017/farmmarket` or Atlas URI).
3. Copy `.env.example` to `.env` and update `MONGO_URI` and `JWT_SECRET`.
4. In project root, run:
   ```
   npm install
   npm run start
   ```
5. The server listens on port 5000 by default. Open `http://localhost:5000` to view the demo frontend.

## Available API routes (examples)
- POST `/api/auth/register` - register (role: farmer/buyer/admin)
- POST `/api/auth/login` - login (returns JWT)
- GET `/api/products` - get all products
- POST `/api/products` - add product (farmer, auth required)
- GET `/api/products/:id` - get product details
- PUT `/api/products/:id` - update product (farmer)
- DELETE `/api/products/:id` - delete product (farmer)
- POST `/api/orders` - place order (buyer)
- GET `/api/orders/buyer/:buyerId` - orders for buyer
- GET `/api/orders/farmer/:farmerId` - orders for farmer
- PUT `/api/orders/:id/status` - update order status (farmer)

## Notes
- This is a starter/demo implementation for hackathon use. Security, validation, and production hardening are minimal.
- Replace placeholders in `.env` before running.
