const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const auth = require('../middleware/auth');

// Add product
router.post('/', auth, async (req, res) => {
  try {
    const { cropName, description, pricePerKg, quantityAvailable, qualityGrade, location, imageUrl } = req.body;

    const product = new Product({
      farmerId: req.user.id,
      cropName,
      description,
      pricePerKg,
      quantityAvailable,
      qualityGrade,
      location,
      imageUrl
    });

    await product.save();
    res.json(product);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

// Get all products
router.get('/', async (req, res) => {
  try {
    const products = await Product.find().populate('farmerId','name');
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
});

module.exports = router;
