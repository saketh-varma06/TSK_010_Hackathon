// Polished frontend interactions for Farm Marketplace demo
(function(){
  const api = '';
  const modalRoot = document.getElementById('modal-root');
  const productsEl = document.getElementById('products');
  const searchEl = document.getElementById('search');

  // Navigation buttons
  document.getElementById('btn-login').addEventListener('click', showAuthModal);
  document.getElementById('btn-add').addEventListener('click', showAddModal);
  document.getElementById('btn-products').addEventListener('click', ()=>document.getElementById('products-section').scrollIntoView({behavior:'smooth'}));
  document.getElementById('btn-orders').addEventListener('click', showOrdersModal);
  document.getElementById('hero-browse').addEventListener('click', ()=>document.getElementById('products-section').scrollIntoView({behavior:'smooth'}));
  document.getElementById('hero-start').addEventListener('click', showAuthModal);

  // Load products
  async function loadProducts(q=''){
    const params = q ? '?'+new URLSearchParams(q).toString() : '';
    const res = await fetch('/api/products'+params);
    const data = await res.json();
    productsEl.innerHTML = data.map(p => productCard(p)).join('');
  }
  function productCard(p){
    return `<div class="product-card">
      <img src="${p.imageUrl}" style="width:100%;height:140px;object-fit:cover;border-radius:8px">(180deg,#f1f5f9,#fff);display:flex;align-items:center;justify-content:center;border-radius:8px">
        <svg width="72" height="72" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C10.343 2 9 3.343 9 5s1.343 3 3 3 3-1.343 3-3S13.657 2 12 2zM6 8C4.343 8 3 9.343 3 11s1.343 3 3 3 3-1.343 3-3S7.657 8 6 8zM18 8c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3-1.343-3-3-3z" fill="#94a3b8"/></svg>
      </div>
      <div>
        <div class="card-row">
          <h3>${escapeHtml(p.cropName)}</h3>
          <div class="price">₹${p.pricePerKg || 0}/kg</div>
        </div>
        <p class="meta">${escapeHtml(p.description || '')}</p>
        <p class="small">Available: ${p.quantityAvailable || 0} kg • Location: ${escapeHtml(p.location || '')}</p>
        <div class="actions" style="justify-content:flex-start;margin-top:10px">
          <button class="btn" onclick="placeOrder('${p._id}', ${p.pricePerKg || 0})">Order</button>
          <button class="btn ghost" onclick="viewDetails('${p._id}')">Details</button>
        </div>
      </div>
    </div>`;
  }

  window.placeOrder = async function(id, price){
    const token = localStorage.getItem('fm_token');
    if(!token){ alert('Please login as buyer to place order'); showAuthModal(); return; }
    const qty = prompt('Enter quantity (kg):','1');
    if(!qty) return;
    const res = await fetch('/api/orders',{method:'POST',headers:{'Content-Type':'application/json','x-auth-token':token},body:JSON.stringify({productId:id, quantityOrdered:+qty})});
    const d = await res.json();
    if(d._id){ alert('Order placed successfully'); } else { alert(d.msg || 'Error placing order'); }
  }
  window.viewDetails = async function(id){
    const res = await fetch('/api/products/'+id);
    const p = await res.json();
    showModal(`<div><h3>${escapeHtml(p.cropName)}</h3><p>${escapeHtml(p.description||'')}</p><p class="small">Price: ₹${p.pricePerKg}/kg | Available: ${p.quantityAvailable} kg</p><div class="actions"><button class="btn" onclick="placeOrder('${p._id}',${p.pricePerKg||0})">Order</button><button class="btn ghost" onclick="closeModal()">Close</button></div></div>`);
  }

  // Orders modal
  async function showOrdersModal(){
    const token = localStorage.getItem('fm_token');
    const user = JSON.parse(localStorage.getItem('fm_user') || 'null');
    if(!token || !user){ alert('Login first'); showAuthModal(); return; }
    let res;
    if(user.role === 'buyer'){
      res = await fetch('/api/orders/buyer/'+user.id, { headers: { 'x-auth-token': token }});
    } else if(user.role === 'farmer'){
      res = await fetch('/api/orders/farmer/'+user.id, { headers: { 'x-auth-token': token }});
    } else {
      showModal('<p>Admin view not implemented in demo.</p>');
      return;
    }
    const data = await res.json();
    const html = data.map(o=>`<div style="border-bottom:1px solid #eee;padding:12px 0"><strong>${escapeHtml(o.productId.cropName||'')}</strong><p class="small">Qty: ${o.quantityOrdered} • ₹${o.totalPrice} • Status: ${o.status}</p>
      ${user.role==='farmer' ? `<div class="actions"><button class="btn" onclick="updateOrderStatus('${o._id}','Accepted')">Mark Accepted</button><button class="btn ghost" onclick="updateOrderStatus('${o._id}','Completed')">Mark Completed</button></div>` : ''}
    </div>`).join('');
    showModal(`<div style="max-height:60vh;overflow:auto">${html || '<p>No orders yet</p>'}</div>`);
  }
  window.updateOrderStatus = async function(id,status){
    const token = localStorage.getItem('fm_token');
    const res = await fetch('/api/orders/'+id+'/status',{method:'PUT',headers:{'Content-Type':'application/json','x-auth-token':token},body:JSON.stringify({status})});
    const d = await res.json();
    if(d._id) alert('Updated'); else if(d.msg) alert(d.msg); else alert('Updated');
    showOrdersModal();
  }

  // Add product modal
  function showAddModal(){
    const token = localStorage.getItem('fm_token');
    const user = JSON.parse(localStorage.getItem('fm_user') || 'null');
    if(!token || user?.role !== 'farmer'){ alert('Login as farmer to add products'); showAuthModal(); return; }
    showModal(`<div>
      <h3>Add new product</h3>
      <div class="form-grid">
        <input id="pcrop" placeholder="Crop name" class="input"/>
        <input id="pprice" placeholder="Price per Kg" class="input" type="number"/>
        <input id="pqty" placeholder="Quantity (kg)" class="input" type="number"/>
        <input id="ploc" placeholder="Location" class="input"/>
      </div>
      <textarea id="pdesc" placeholder="Short description" class="input" style="width:100%;margin-top:8px"></textarea>
      <div class="actions"><button class="btn" id="add-save">Add</button><button class="btn ghost" onclick="closeModal()">Cancel</button></div>
    </div>`);
    document.getElementById('add-save').addEventListener('click', async ()=>{
      const body = {
        cropName: document.getElementById('pcrop').value,
        description: document.getElementById('pdesc').value,
        pricePerKg: +document.getElementById('pprice').value || 0,
        quantityAvailable: +document.getElementById('pqty').value || 0,
        location: document.getElementById('ploc').value
      };
      const res = await fetch('/api/products',{method:'POST',headers:{'Content-Type':'application/json','x-auth-token':localStorage.getItem('fm_token')},body:JSON.stringify(body)});
      const d = await res.json();
      if(d._id){ alert('Product added'); closeModal(); loadProducts(); } else alert(d.msg || 'Error');
    });
  }

  // Auth modal
  function showAuthModal(){
    showModal(`<div>
      <div style="display:flex;gap:12px;align-items:center;justify-content:space-between">
        <h3>Welcome</h3>
        <div class="small">Demo credentials will be stored locally</div>
      </div>
      <div style="display:flex;gap:12px;margin-top:8px">
        <div style="flex:1">
          <h4>Register</h4>
          <input id="rname" placeholder="Full name" class="input"/><br/><br/>
          <input id="remail" placeholder="Email" class="input"/><br/><br/>
          <input id="rpass" type="password" placeholder="Password" class="input"/><br/><br/>
          <select id="rrole" class="input small"><option value="farmer">Farmer</option><option value="buyer">Buyer</option></select><br/><br/>
          <div class="actions"><button class="btn" id="regbtn">Register</button></div>
        </div>
        <div style="flex:1">
          <h4>Login</h4>
          <input id="lemail" placeholder="Email" class="input"/><br/><br/>
          <input id="lpass" type="password" placeholder="Password" class="input"/><br/><br/>
          <div class="actions"><button class="btn" id="loginbtn">Login</button></div>
        </div>
      </div>
    </div>`);
    document.getElementById('regbtn').addEventListener('click', async ()=>{
      const body = { name:document.getElementById('rname').value, email:document.getElementById('remail').value, password:document.getElementById('rpass').value, role:document.getElementById('rrole').value };
      const res = await fetch('/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      const d = await res.json();
      if(d.token){ localStorage.setItem('fm_token', d.token); localStorage.setItem('fm_user', JSON.stringify(d.user)); alert('Registered & logged in'); closeModal(); } else alert(d.msg || 'Error');
    });
    document.getElementById('loginbtn').addEventListener('click', async ()=>{
      const body = { email:document.getElementById('lemail').value, password:document.getElementById('lpass').value };
      const res = await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      const d = await res.json();
      if(d.token){ localStorage.setItem('fm_token', d.token); localStorage.setItem('fm_user', JSON.stringify(d.user)); alert('Logged in'); closeModal(); } else alert(d.msg || 'Login failed');
    });
  }

  // Modal utilities
  function showModal(html){
    modalRoot.innerHTML = `<div class="modal" id="modal"><div class="modal-card">${html}</div></div>`;
    document.getElementById('modal').addEventListener('click', (e)=>{ if(e.target.id==='modal') closeModal(); });
  }
  function closeModal(){ modalRoot.innerHTML = ''; }

  // Helpers
  function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, (m)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

  // load initial products
  loadProducts();

  // search
  searchEl.addEventListener('keyup', (e)=>{ if(e.key==='Enter') loadProducts({ cropName: searchEl.value, location: searchEl.value }); });

})();
